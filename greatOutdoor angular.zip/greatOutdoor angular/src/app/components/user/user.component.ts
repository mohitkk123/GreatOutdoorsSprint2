import { Component, OnInit } from '@angular/core';
import { Product } from '../../entities/product';
import { CrudServiceService } from '../../services/crud-service.service';
import { PushCart } from 'src/app/entities/pushcart';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
 
  //component for displaying user interface

  searchString:string;
  errorLog:String;
  products:Product[]=[];
  search:boolean=false;
  test:number[]=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
 data:PushCart;
 result:boolean;

  constructor(private cService:CrudServiceService) { }
  pushcart:PushCart={
  
    "productName": "Rope",
    "productManufacturer": "ABC",
    "productCategory": "CAMPING",
    "productQuantity": 3,
    "productDescription": "This rope is specially designed for weight upto 500kg",
    "productcost": 100.0,
  };
  ngOnInit(): void {
    
    this.cService.getAllProducts().subscribe(data=>{
      this.products=data;
      this.errorLog=undefined;
    },
    error=>{
     this.errorLog=error.error;
    });

    console.log(this.products.length);

  }

    // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : click - Input Parameters : PushCart - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to push product to cart in the
		 * server
		 * 
		
		 ********************************************************************************************************/
  click(Name,Manufacturer,Category,Description,cost)
  {
    this.pushcart.productCategory=Category;
    this.pushcart.productDescription=Description;
    this.pushcart.productManufacturer=Manufacturer;
    this.pushcart.productName=Name;
    this.pushcart.productcost=cost;

    this.cService.pushIntoCart(this.pushcart).subscribe(data=>{
      this.result=data;
      this.data=data;
     },error=>{
      this.errorLog=error.error;
     });
 }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name :searchProduct - Input Parameters :- - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to search a product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  searchProduct(){
    this.search=true;
    this.cService.searchProduct(this.searchString).subscribe(data=>{
     this.products=data;
     this.errorLog=undefined;
    },
   error=>{
    this.errorLog=error.error;
    this.products=[];
   });

   console.log(this.products.length);

  }

    // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : quanChange - Input Parameters : Value:number - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to change quantity of the product f
		 * 
		
		 ********************************************************************************************************/
  quanChange(value){
    console.log(value);
    this.pushcart.productQuantity=value;
  }
   
    //for logging into the console

  log(x){
    console.log(x);
  }

}
