import { Component, OnInit } from '@angular/core';
import { CrudServiceService } from 'src/app/services/crud-service.service';
import { GetCart } from 'src/app/entities/getcart';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  getcart:GetCart[];
  result:boolean;
  errorLog:String;
  test:number[]=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
  constructor(private cService:CrudServiceService) { }

  ngOnInit(): void {
    this.cService.getCartProducts().subscribe(data=>{
      this.getcart=data;
    });
  }
  deleteProduct(id:number){
   
    this.cService.deleteCartProduct(id).subscribe(data=>{
      this.result=data;
      this.errorLog=undefined;
    },error=>{
      this.errorLog=error.error;
     });
  }

}
