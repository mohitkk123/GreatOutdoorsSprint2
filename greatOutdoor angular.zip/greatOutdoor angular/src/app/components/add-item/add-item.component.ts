import { Component, OnInit } from '@angular/core';
import { Product } from '../../entities/product';
import { Router } from '../../../../node_modules/@angular/router';
import { CrudServiceService } from '../../services/crud-service.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  //component class for adding the product

 product:Product=new Product();
 result:number;
 errorLog:string;

 success:boolean=false;
 name:string;
 Category:string[]=["GOLF","MOUNTAINEERING","CAMPING","INDOOR","ATHLETE","FOOTBALL"];
  constructor(private router:Router,private cService:CrudServiceService) { }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : sendProduct - Input Parameters : - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to add the product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  sendProduct(){
 if(this.product.productCategory=="" || this.product.productcost==null || this.product.productDescription=="" || this.product.productManufacturer=="" || this.product.productQuantity==null || this.product.productName=="")
    { 
      
    }else{
      this.cService.addProduct(this.product).subscribe(data=>{
        this.result=data;
        this.errorLog=undefined;
        this.success=true;
      },
      error=>{
      this.errorLog=error.error;
      });
    
    //console.log(name);
    }
  }


  consoleLog(fname){
    console.log(fname) ;
  }

  ngOnInit(): void {
  }

    // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : changeCat - Input Parameters : Value:number - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to change category of the product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  changeCat(value){
    this.product.productCategory=value;
  }

}
