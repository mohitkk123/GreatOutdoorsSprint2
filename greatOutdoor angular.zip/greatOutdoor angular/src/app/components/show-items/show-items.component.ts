import { Component, OnInit } from '@angular/core';
import { CrudServiceService } from '../../services/crud-service.service';
import { Product } from '../../entities/product';

@Component({
  selector: 'app-show-items',
  templateUrl: './show-items.component.html',
  styleUrls: ['./show-items.component.css']
})
export class ShowItemsComponent implements OnInit {

  //component for  displaying all products

  pro:Product=new Product();
  products:Product[]=[];
  result:number;
 
  errorLog:String;
  showForm:boolean=false;
  success:boolean=false;
  Category:string[]=["GOLF","MOUNTAINEERING","CAMPING","INDOOR","ATHLETE","FOOTBALL"];

  constructor(private cService:CrudServiceService) {

   }



  ngOnInit(): void {
      this.cService.getAllProducts().subscribe(data=>{
        this.products=data;
        this.errorLog=undefined;
      },
      error=>{
       this.errorLog=error.error;
      });
   
   
  }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : sendProduct - Input Parameters : - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to update the product to the
		 * server
		 * 
		
		 ********************************************************************************************************/

  sendProduct(){

    if(this.pro.productCategory=="" || this.pro.productcost==null || this.pro.productDescription=="" || this.pro.productManufacturer=="" || this.pro.productQuantity==null || this.pro.productName=="")
    { 
     
    }else{
      this.cService.updateProduct(this.pro).subscribe(data=>{
        this.result=data;
        this.errorLog=undefined;
        this.success=true;
      },
      error=>{
      this.errorLog=error.error;
      });
    
    //console.log(name);
    }


  }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : changeCat - Input Parameters : Value:number - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to change category of the product from the
		 * server
		 * 
		
		 ********************************************************************************************************/


  changeCat(value){
    this.pro.productCategory=value;
  } 


   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : displayForm - Input Parameters : - Return Type :
		 * -- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to toggle the form view
		 * 
		
		 ********************************************************************************************************/

  displayForm(prod:Product){
   
    this.showForm=true;
    //console.log(i);
    this.pro=prod;
  }

}
