import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { Product } from '../entities/product';
import { PushCart } from '../entities/pushcart';
import { GetCart } from '../entities/getcart';

@Injectable({
  providedIn: 'root'
})
export class CrudServiceService {

  constructor(private http:HttpClient) { }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : getAllProducts - Input Parameters : - Return Type :
		 * Observable<Product>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to get all the product from the
		 * server
		 * 
		
		 ********************************************************************************************************/


  getAllProducts():Observable<any>{
    return this.http.get("http://localhost:9000/dashboard/Products");

  }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name :addProduct - Input Parameters : Product product Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to add a product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  addProduct(product:Product):Observable<any>{
    return this.http.post("http://localhost:9000/dashboard/addProduct",product,{responseType:"text"});

  }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : deleteItem - Input Parameters : number id Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to delete a product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  deleteItem(id:number):Observable<any>{
    return this.http.delete(`http://localhost:9000/dashboard/deleteProduct/${id}`);
  }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : searchProducts - Input Parameters :string name Return Type :
		 * Observable<Product>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to search a product from the
		 * server
		 * 
		
		 ********************************************************************************************************/

  searchProduct(search:string):Observable<any>{

    return this.http.get(`http://localhost:9000/dashboard/searchProducts/${search}`);
  }

  // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : pushIntoCart - Input Parameters : pushcart Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to add product to cart in the
		 * server
		 * 
		
		 ********************************************************************************************************/

  pushIntoCart(pushcart:PushCart):Observable<any>{
    console.log(pushcart);
    return this.http.post(`http://localhost:9000/carts`,pushcart);
  }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : updateProduct - Input Parameters : Product product  Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to update a product  in the
		 * server
		 * 
		
		 ********************************************************************************************************/

  updateProduct(product:Product):Observable<any>{
    console.log(product);
    return this.http.put("http://localhost:9000/dashboard/editProduct",product,{responseType:"text"});
  }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : getCart - Input Parameters : - Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to get products from cart in the
		 * server
		 * 
		
		 ********************************************************************************************************/
  getCartProducts():Observable<any>{
    return this.http.get("http://localhost:9000/carts");
  }

   // ------------------------ GreatOutdoor Application --------------------------
		/*******************************************************************************************************
		 * - Function Name : updateCartProduct - Input Parameters : GetCrt Return Type :
		 * Observable<any>- Author : Mohit kumar Mastana -
		 * Creation Date : 28/04/2020 - Description : to update a product to cart in the
		 * server
		 * 
		
		 ********************************************************************************************************/
  updateCartProduct(getcart:GetCart):Observable<any>{
    
    return this.http.put("http://localhost:9000/carts",getcart,{responseType:"text"});
  }
  deleteCartProduct(id:number):Observable<any>{
    return this.http.delete(`http://localhost:9000/carts/`+id);
  }



}
