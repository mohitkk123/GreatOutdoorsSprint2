export class GetCart {
    productName:string;
	 productManufacturer:string;
	 productCategory:string;
	productQuantity:number;
	
	productDescription:string;
    productcost:number;
    productId:number;


}
