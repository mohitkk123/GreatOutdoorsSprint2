export class Product {
    productid:number;
    productName:string;
	 productManufacturer:string;
	 productCategory:string;
	productQuantity:number;
	
	productDescription:string;
	productcost:number;


}
