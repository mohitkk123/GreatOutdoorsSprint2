export class PushCart {
    productName:string;
	 productManufacturer:string;
	 productCategory:string;
	productQuantity:number;
	
	productDescription:string;
	productcost:number;


}
